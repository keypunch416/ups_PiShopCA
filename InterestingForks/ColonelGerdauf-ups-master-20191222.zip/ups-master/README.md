# howto:
### Download the initialization script
```
  wget -nd https://raw.githubusercontent.com/buyapi/ups/master/pi_ups_startup.sh
```
### Run the script
```
  pi_ups_startup.sh
```
